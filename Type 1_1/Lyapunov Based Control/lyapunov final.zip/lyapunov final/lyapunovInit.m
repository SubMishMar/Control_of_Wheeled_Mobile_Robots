clear;
clc;

R=2;
wd=0.5;
a=0.13;
r=0.1;

kx=25;
ky=25;
kpsi=10;

x0=2.3;
y0=0;
theta0=pi;

